### Multi User Auth System

1. Please perform the following steps
2. After migrate the code. Please run the db:seed command for create a admin account
3. User can able to register and login our account
4. Admin can view the all user in listing with pagination
5. User can edit our profile and upload the image